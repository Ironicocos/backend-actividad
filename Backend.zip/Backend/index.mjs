import express from 'express';
const app = express();

const users = []

app.get("/users" , (req, ress) => {
	res.json ({
		users: user
	})
})

app.post("/create" , (res,req) => {
	const user = req.body
	user.id = users.length
	users.push(user)

	res.json ({
		msg: "User nuevo: ",user

	})
})

app.put("./update",(request, response) =>{
	const UserUp = req.body

	users = users.map(e=> {
		if (e.id == UserUp.id) {
			e=UserUp
		}
		return e
	})
	res.json ({
		msg: "user updated"
	})
})


app.listen( 3000, () => {
	console.log (" mi backend esta  escuchado en el puerto 3000")
})

app.delete("/eliminar", (request, response) => {
	response.json ({msg : "crotolamo"})
})



app.post("/crear", (req , res) =>
	res.status(200).json({nsg: "status"}) )




	.nuke







	