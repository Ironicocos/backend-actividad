import axios from "axios"

axios.post('http://localhost:3000/create',{
    nombre: 'nombre',
    apellido: 'apellido',
    edad: 18}
).then(respuesta => {
    console.log('respuesta: ',respuesta.data)
}).catch(error => {
    console.error(error)
})

axios.get('http://localhost:3000/users').then(respuesta => {
    console.log('respuesta: ',respuesta.data)})