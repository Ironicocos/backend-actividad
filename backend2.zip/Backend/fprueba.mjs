import axios from "axios"

axios.post('http://localhost:3000/create',{
    nombre: 'alex',
    dni: 42,
    apellido: 'valdiviezo',
    edad: 23}
).then(respuesta => {
    console.log('respuesta: ',respuesta.data)
}).catch(error => {
    console.error('error')
})