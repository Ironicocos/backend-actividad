import express from 'express';
import fs from "fs";

const app = express();

app.use(express.json())

const DataBase = {
	file: './data.json',
	load(){
		return JSON.parse(fs.readFileSync(this.file))
	},
	save(data){
		fs.writeFileSync(this.file, JSON.stringify(data))
	},
	display(id){
		const data = this.load();

	},
	delete(id){
		const data = this.load()
		data.forEach((element, index) => {
			if(element.id === id){
				data.splice(index, 1, )
			}
		})
		this.save(data)
	}
}

const users = DataBase.load()

console.log('first: ', users)

app.get("/users" , (req, res) => {
	res.json ({
		users: user
	})
})

DataBase.delete(3);

app.post("/create" , (req,res) => {
	/* const user = {}

	user.nombre = req.body.nombre
	user.apellido = req.body.apellido
	user.edad = req.body.edad

	user.id = users.length
*/
	users.push(user)

	DataBase.save(users)

	res.json ({
		msg: "User nuevo: ",
		user
	})
})

app.put("./update",(request, response) =>{
	const UserUp = req.body

	users = users.map(e=> {
		if (e.id == UserUp.id) {
			e=UserUp
		}
		return e
	})
	res.json ({
		msg: "user updated"
	})
})


app.listen( 3000, () => {
	console.log (" mi backend esta  escuchado en el puerto 3000")
})

app.post("/crear", (req , res) =>
	res.status(200).json({nsg: "status"}) )




	.nuke 







	